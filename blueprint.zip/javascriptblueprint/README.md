# javascriptblueprint
Tutorial self-teaching my JavaScript code from the book JavaScript: Your Visual Blueprint for Building Dynamic Web Pages, 2nd Edition.
