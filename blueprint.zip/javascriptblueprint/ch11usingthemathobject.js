radius = 5;
document.write(radius * Math.PI);  //write 15.707963267948966
document.write("<br>");
document.write(Math.pow(2,3));  //write 8
document.write("<br>");
randommax = 24;
document.write(Math.random() * randommax);
document.write("<br>");
document.write(Math.floor((Math.random() * randommax)));
document.write("<br>");

numbersample = 246.855
document.write(Math.round(numbersample)); //write 247
document.write("<br>");
document.write(Math.ceil(numbersample));  //write 247
document.write("<br>");
document.write(Math.floor(numbersample));  //write 246
document.write("<br>");
document.write(Math.pow(numbersample,3));  //write 15042699.661476374
document.write("<br>");
document.write(Math.min(3,7,9,numbersample));  //write 3
document.write("<br>");
document.write(Math.max(3,7,9,numbersample));  //write 246.855
document.write("<br>");
document.write(Math.abs(numbersample * -1)); //write 246.855
