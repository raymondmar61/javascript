//alert("Hello this is an external js page!")

var x = 5;
var y = 2;
var z = (x + y) * 3;
alert (z);