document.write("<p>We are using a js file</p>");
document.write("<p>It seems an external file can't be nested inside script type=text/javascript /script </p>");