# javascriptjavascriptworldwideweb
Tutorial self-teaching my JavaScript code from book JavaScript For The World Wide Web.
