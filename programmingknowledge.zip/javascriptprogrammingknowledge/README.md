# javascriptprogrammingknowledge
Tutorial self-teaching my JavaScript code from YouTube programmingknowledge.
