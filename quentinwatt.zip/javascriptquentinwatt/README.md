# javascriptquentinwatt
Tutorial self-teaching my JavaScript code from YouTube Quentin Watt.
