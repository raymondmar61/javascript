var car = "porsche";

switch(car) {
	case "ferari":
		document.write("italian stalion hey?");
		break;
	case "porsche":
		document.write("German precision, I like that");
		break;
	case "dodge":
		document.write("American cars can't corner properly");
		break;
	default:
		document.write("I don't know that car");
		//no break statement needed in default:
}