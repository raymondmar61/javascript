# javascriptthenetninja
Tutorial self-teaching my JavaScript code from YouTube The Net Ninja.
