# javascriptthenewboston
Tutorial self-teaching JavaScript from YouTube thenewboston.
